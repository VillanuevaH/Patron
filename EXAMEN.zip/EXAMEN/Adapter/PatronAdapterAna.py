'''
Ana Villanueva
GITI11071-E
'''
from abc import ABC, abstractmethod

class Dispositivo(ABC):
    @abstractmethod
    def conectar(self):
        pass

class USB(Dispositivo):
    def conectar(self):
        print("Conectar dispositivo USB")

class Audifono(Dispositivo):
    def conectar(self):
        print("Conectar dispositivo Audifono")

class Canon:
    def conectorvga(self):
        print("Conectar dispositivo Cañon")
        
class HdmiAdapter(Dispositivo):
    def __init__(self):
        self._canon = Canon()

    def conectar(self):
        print("Adaptador para conectar Cañon")

class ClaseMultimedia:
    def __init__(self):
        self.mi_usb = USB()
        self.bocinas = Audifono()
        self.canon_utng = HdmiAdapter()
        self.canon_utng.conectar()
        self.mi_usb.conectar()
        self.bocinas.conectar()

Presentacion = ClaseMultimedia()
