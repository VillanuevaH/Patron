'''
Ana Villanueva
GITI11071-E
'''
from abc import ABC, abstractmethod

class Artista(ABC):

    def get_description():
        pass
        
    @abstractmethod
    def combinacion(vestimenta):
        
        def frase():
            print("Usar vestuario en escena:")

            accesorio()

            print("Quitar vestuario fuera de escena:")
            
        return frase
        
class Actor_Teatro(Artista):
    
    print("Brad Pit")
    
class Vestuario(Artista):
    def __init__(self):
        self._artista = Artista()
    def get_description():
        print("Vestuario de la Escena ")
        
class Vestido(Vestuario):
    def combinacion(self):
        print("Un vestido")

class Pantalon(Vestuario):
    def combinacion(self):
        print("Unos pantalones")
        
class Falda(Vestuario):
    def combinacion(self):
        print("Una falda")

class Escena(Actor_Teatro, Vestuario):
    def __init__ (self):
        self._Brad_Pit = Actor_Teatro()

    def __init__(self):
        self.artista = Artista()

