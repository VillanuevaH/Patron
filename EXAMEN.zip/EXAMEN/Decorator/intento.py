from abc import ABC, abstractmethod


    
def combinacion(ropa):
        
    def frase():
        print("Hoy es el mejor día para ponernos:")

        ropa()

        print("Hora de lucir nuestro vesturario")
            
    return frase
        
@combinacion
def Vestido():
    print(" Un vestido")

@combinacion
def Pantalones():
    print(" Unos pantalones")
        
Vestido()
Pantalones()
