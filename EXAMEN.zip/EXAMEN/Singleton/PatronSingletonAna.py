'''
Ana Villanueva
GITI11071-E
'''
from abc import ABC, abstractmethod

class Califiacion(object):
    _instance = None
    def __new__(self):
        if not self._instance:
            self._instance = super(Califiacion, self).__new__(self)
            self.calif1 = 10
            return self._instance

calif2 = Califiacion()
print (calif2.calif1)
calif2.calif1 = 20
calif3 = Califiacion()
print (calif3)
