'''
Ana Villanueva
GITI11071-E
'''
from abc import ABC, abstractmethod

class SistemaOperativo(ABC):

    @abstractmethod
    def instalar(self):
        pass

class SoLinux(SistemaOperativo):
    def instalar(self):
        return("Instalar el Sistema Operativo Linux")

class SoWindows(SistemaOperativo):
    def instalar(self):
        return("Instalar el Sistema Operativo Windows")

class SoFactory:
    def get_SistemaOperativo_instalar(self, SistemaOperativo):
        return SistemaOperativo.instalar()

class Client(SistemaOperativo):
    def __init__(self):
        self.factory = SoFactory()
        print(self.factory.get_SistemaOperativo_instalar(SoLinux()))
        print(self.factory.get_SistemaOperativo_instalar(SoWindows()))
    def instalar(self):
        pass

persona = Client()
