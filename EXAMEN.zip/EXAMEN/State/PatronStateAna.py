'''
Ana Villanueva
GITI11071-E
'''
from abc import ABC, abstractmethod

class Estado(ABC):
    def __init__(self, nombre):
        self.nombre = Gonzalo

    @abstractmethod
    def emociones():
        print("Estado: ")

class Feliz(Estado):
    def emociones(self):
        print("Sonríe")

class Triste(Estado):
    def emociones(self):
        print("Llora")

class Enojado(Estado):
    def emociones(self):
        print("Berrinche")

class client(Estado):

    def emociones(self):
        pass
    
